ALTER TABLE `#__sppagebuilder_sections` CHANGE `section` `section` MEDIUMTEXT NOT NULL;
ALTER TABLE `#__sppagebuilder_addons` CHANGE `code` `code` MEDIUMTEXT NOT NULL;